from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.views.generic import View
from .models import Post, Tag
from django.shortcuts import redirect

from django.urls import reverse
from .utils import *
from .forms import TagForm, PostForm
from django.contrib.auth.mixins import LoginRequiredMixin

def posts_list(request):
	posts =   Post.objects.all()
	return render(request, 'login/login.html', context={'posts': posts})

class PostDetail(ObjectDetailMixin, View):
	model = Post
	template = 'login/post_detail.html'


class  PostCreate(LoginRequiredMixin, ObjectCreateMixin,View):
	model_form = PostForm
	template = 'login/post_create_form.html'
	raise_exception = True

class PostUpdate(LoginRequiredMixin, ObjectUpdateMixin, View): 
	model = Post
	model_form = PostForm
	template = 'login/post_update_form.html'


class PostDelete(LoginRequiredMixin, ObjectDeleteMixin, View):
	model = Post
	template = 'login/post_delete_form.html'
	redirect_url = 'posts_list_url'
	raise_exception = True


class TagDetail(ObjectDetailMixin,View):
	model = Tag 
	template = 'login/tag_detail.html'

class TagCreate(LoginRequiredMixin, ObjectCreateMixin, View):
	model_form = TagForm
	template = 'login/tag_create.html'
	raise_exception = True

class TagUpdate(LoginRequiredMixin, ObjectUpdateMixin, View):
	model = Tag
	model_form =TagForm
	template = 'login/tag_update_form.html'
	raise_exception = True

class TagDelete(LoginRequiredMixin, ObjectDeleteMixin, View):
	model = Tag
	template = 'login/tag_delete_form.html'
	redirect_url = 'tags_list_url'
	raise_exception = True

def tags_list(request):
	tags = Tag.objects.all()
	return render(request,'login/tags_list.html', context={'tags': tags})


